import React from "https://esm.sh/react";
import ReactDOM from "https://esm.sh/react-dom";
import Portfolio from "./Portfolio.js";

ReactDOM.render(React.createElement(Portfolio), document.getElementById("root"));
